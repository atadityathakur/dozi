<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Groups enjoy a lively quiz night together, hosted by anyone.

## Metric

Quiz games played to the final question with players in the room, each week
