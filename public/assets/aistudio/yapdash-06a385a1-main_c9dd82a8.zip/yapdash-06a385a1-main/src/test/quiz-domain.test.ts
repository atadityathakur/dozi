import { describe, expect, it } from "vitest";

import { canAddPlayer, canAnswerAt, pointsForCorrectAnswer, ROOM_PLAYER_LIMIT, validateQuiz } from "@/lib/quiz-domain";

describe("quiz rules", () => {
  it("caps a room at the user's chosen 100 players", () => {
    expect(ROOM_PLAYER_LIMIT).toBe(100);
    expect(canAddPlayer(99)).toBe(true);
    expect(canAddPlayer(100)).toBe(false);
  });

  it("scores a correct answer between 500 and 1000 points with a 50-point streak bonus capped at 250", () => {
    expect(pointsForCorrectAnswer(0, 20, 1)).toEqual({ base: 1000, bonus: 0, total: 1000 });
    expect(pointsForCorrectAnswer(20000, 20, 9)).toEqual({ base: 500, bonus: 250, total: 750 });
  });

  it("accepts a quiz answer through the 400 ms deadline grace, but not after it", () => {
    expect(canAnswerAt(10_400, 10_000)).toBe(true);
    expect(canAnswerAt(10_401, 10_000)).toBe(false);
  });

  it("rejects questions without a valid correct option", () => {
    expect(validateQuiz({ title: "Broken", questions: [{ text: "Q?", options: ["A", "B"], correct: 2 }] })).toBeNull();
  });
});