export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.18"
  }
  public: {
    Tables: {
      daily_yap_accounts: {
        Row: {
          created_at: string
          player_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          player_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          player_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "daily_yap_accounts_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: true
            referencedRelation: "daily_yap_players"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_yap_answers: {
        Row: {
          answered_at: string
          attempt_id: string
          is_correct: boolean
          points: number
          question_index: number
          response_ms: number
          selected_choice: number | null
        }
        Insert: {
          answered_at?: string
          attempt_id: string
          is_correct: boolean
          points?: number
          question_index: number
          response_ms: number
          selected_choice?: number | null
        }
        Update: {
          answered_at?: string
          attempt_id?: string
          is_correct?: boolean
          points?: number
          question_index?: number
          response_ms?: number
          selected_choice?: number | null
        }
        Relationships: [
          {
            foreignKeyName: "daily_yap_answers_attempt_id_fkey"
            columns: ["attempt_id"]
            isOneToOne: false
            referencedRelation: "daily_yap_attempts"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_yap_attempts: {
        Row: {
          challenge_date: string
          completed_at: string | null
          correct_count: number
          id: string
          next_question: number
          player_id: string
          question_started_at: string
          score: number
          started_at: string
          status: string
          total_response_ms: number
        }
        Insert: {
          challenge_date: string
          completed_at?: string | null
          correct_count?: number
          id?: string
          next_question?: number
          player_id: string
          question_started_at?: string
          score?: number
          started_at?: string
          status?: string
          total_response_ms?: number
        }
        Update: {
          challenge_date?: string
          completed_at?: string | null
          correct_count?: number
          id?: string
          next_question?: number
          player_id?: string
          question_started_at?: string
          score?: number
          started_at?: string
          status?: string
          total_response_ms?: number
        }
        Relationships: [
          {
            foreignKeyName: "daily_yap_attempts_challenge_date_fkey"
            columns: ["challenge_date"]
            isOneToOne: false
            referencedRelation: "daily_yap_challenges"
            referencedColumns: ["challenge_date"]
          },
          {
            foreignKeyName: "daily_yap_attempts_player_id_fkey"
            columns: ["player_id"]
            isOneToOne: false
            referencedRelation: "daily_yap_players"
            referencedColumns: ["id"]
          },
        ]
      }
      daily_yap_challenges: {
        Row: {
          challenge_date: string
          created_at: string
          difficulty: string
          estimated_minutes: number
          questions: Json
          title: string
        }
        Insert: {
          challenge_date: string
          created_at?: string
          difficulty: string
          estimated_minutes: number
          questions: Json
          title: string
        }
        Update: {
          challenge_date?: string
          created_at?: string
          difficulty?: string
          estimated_minutes?: number
          questions?: Json
          title?: string
        }
        Relationships: []
      }
      daily_yap_players: {
        Row: {
          created_at: string
          current_streak: number
          guest_token_hash: string | null
          id: string
          last_completed_date: string | null
          last_perfect_date: string | null
          linked_user_id: string | null
          longest_perfect_score_streak: number
          longest_streak: number
          perfect_score_streak: number
          username: string
        }
        Insert: {
          created_at?: string
          current_streak?: number
          guest_token_hash?: string | null
          id?: string
          last_completed_date?: string | null
          last_perfect_date?: string | null
          linked_user_id?: string | null
          longest_perfect_score_streak?: number
          longest_streak?: number
          perfect_score_streak?: number
          username: string
        }
        Update: {
          created_at?: string
          current_streak?: number
          guest_token_hash?: string | null
          id?: string
          last_completed_date?: string | null
          last_perfect_date?: string | null
          linked_user_id?: string | null
          longest_perfect_score_streak?: number
          longest_streak?: number
          perfect_score_streak?: number
          username?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          updated_at: string
          user_id: string
          username: string
        }
        Insert: {
          created_at?: string
          updated_at?: string
          user_id: string
          username: string
        }
        Update: {
          created_at?: string
          updated_at?: string
          user_id?: string
          username?: string
        }
        Relationships: []
      }
      quiz_room_events: {
        Row: {
          room_code: string
          updated_at: string
        }
        Insert: {
          room_code: string
          updated_at?: string
        }
        Update: {
          room_code?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "quiz_room_events_room_code_fkey"
            columns: ["room_code"]
            isOneToOne: true
            referencedRelation: "quiz_rooms"
            referencedColumns: ["code"]
          },
        ]
      }
      quiz_room_presence: {
        Row: {
          last_seen: string
          member_id: string
          role: string
          room_code: string
        }
        Insert: {
          last_seen?: string
          member_id: string
          role: string
          room_code: string
        }
        Update: {
          last_seen?: string
          member_id?: string
          role?: string
          room_code?: string
        }
        Relationships: [
          {
            foreignKeyName: "quiz_room_presence_room_code_fkey"
            columns: ["room_code"]
            isOneToOne: false
            referencedRelation: "quiz_rooms"
            referencedColumns: ["code"]
          },
        ]
      }
      quiz_rooms: {
        Row: {
          code: string
          created_at: string
          host_secret_hash: string
          state: Json
          updated_at: string
          version: number
        }
        Insert: {
          code: string
          created_at?: string
          host_secret_hash: string
          state: Json
          updated_at?: string
          version?: number
        }
        Update: {
          code?: string
          created_at?: string
          host_secret_hash?: string
          state?: Json
          updated_at?: string
          version?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      daily_yap_leaderboards: {
        Args: { _player_id?: string; _today: string }
        Returns: Json
      }
      daily_yap_start_attempt: {
        Args: { _challenge_date: string; _player_id: string }
        Returns: {
          challenge_date: string
          completed_at: string | null
          correct_count: number
          id: string
          next_question: number
          player_id: string
          question_started_at: string
          score: number
          started_at: string
          status: string
          total_response_ms: number
        }
        SetofOptions: {
          from: "*"
          to: "daily_yap_attempts"
          isOneToOne: true
          isSetofReturn: false
        }
      }
      daily_yap_submit_answer: {
        Args: { _attempt_id: string; _choice: number; _question_index: number }
        Returns: Json
      }
      ensure_daily_yap_account: {
        Args: {
          _guest_token_hash?: string
          _user_id: string
          _username: string
        }
        Returns: string
      }
      quiz_room_compare_and_swap: {
        Args: { _code: string; _expected_version: number; _new_state: Json }
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
