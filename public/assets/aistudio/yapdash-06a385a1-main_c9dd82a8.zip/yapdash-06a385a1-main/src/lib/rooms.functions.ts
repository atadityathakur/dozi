import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

import {
  ANSWER_GRACE_MS,
  canAnswerAt,
  canAddPlayer,
  cleanText,
  pointsForCorrectAnswer,
  ROOM_IDLE_MS,
  ROOM_PLAYER_LIMIT,
  standings,
  validateQuiz,
  type Quiz,
} from "@/lib/quiz-domain";

type Player = {
  id: string;
  name: string;
  tokenHash: string;
  score: number;
  correct: number;
  streak: number;
  last: { q: number; choice: number | null; correct: boolean; points: number; bonus: number } | null;
};

type StoredRoom = {
  quiz: Quiz;
  phase: "lobby" | "question" | "reveal" | "final";
  players: Player[];
  qIndex: number;
  qStart: number;
  qEnd: number;
  answers: Record<string, { choice: number; at: number }>;
  counts: number[] | null;
  qStats: Array<{ text: string; correct: number; answered: number; total: number } | null>;
  lastActivity: number;
};

type Role = "host" | "player";
type Auth = { role: Role; hostKey?: string; playerToken?: string };

const codeSchema = z.string().regex(/^\d{6}$/);
const credentialSchema = z.string().min(32).max(128);
const actionSchema = z.discriminatedUnion("action", [
  z.object({ action: z.literal("heartbeat") }),
  z.object({ action: z.literal("start") }),
  z.object({ action: z.literal("skip") }),
  z.object({ action: z.literal("next") }),
  z.object({ action: z.literal("kick"), playerId: z.string().min(1).max(64) }),
  z.object({ action: z.literal("restart") }),
  z.object({ action: z.literal("end") }),
  z.object({ action: z.literal("answer"), questionIndex: z.number().int().nonnegative(), choice: z.number().int().min(0).max(3) }),
  z.object({ action: z.literal("leave") }),
  z.object({ action: z.literal("tick") }),
]);

function randomHex(bytes = 24) {
  const values = new Uint8Array(bytes);
  crypto.getRandomValues(values);
  return Array.from(values, (value) => value.toString(16).padStart(2, "0")).join("");
}

async function hashSecret(secret: string) {
  const bytes = new TextEncoder().encode(secret);
  const digest = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest), (value) => value.toString(16).padStart(2, "0")).join("");
}

async function adminClient() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function fetchRoom(code: string) {
  const db = await adminClient();
  const { data, error } = await db.from("quiz_rooms").select("code, host_secret_hash, state, version, updated_at").eq("code", code).maybeSingle();
  if (error) throw new Error("Could not reach this quiz room.");
  if (!data) throw new Error("That room has ended or the code is incorrect.");
  const room = data.state as unknown as StoredRoom;
  if (Date.now() - Date.parse(data.updated_at) > ROOM_IDLE_MS) {
    await db.from("quiz_rooms").delete().eq("code", code);
    throw new Error("That room has ended after being inactive.");
  }
  return { db, row: data, room };
}

async function compareAndSwap(db: Awaited<ReturnType<typeof adminClient>>, code: string, version: number, room: StoredRoom) {
  const { data, error } = await db.rpc("quiz_room_compare_and_swap", {
    _code: code,
    _expected_version: version,
    _new_state: room as never,
  });
  if (error) throw new Error("Could not update the quiz room.");
  return data === true;
}

async function withRoomUpdate<T>(code: string, update: (ctx: { db: Awaited<ReturnType<typeof adminClient>>; row: Awaited<ReturnType<typeof fetchRoom>>["row"]; room: StoredRoom }) => Promise<T>) {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const ctx = await fetchRoom(code);
    const result = await update(ctx);
    if (ctx.row.version === -1) return result;
    if (await compareAndSwap(ctx.db, code, ctx.row.version, ctx.room)) return result;
    await new Promise<void>((resolve) => setTimeout(resolve, (attempt + 1) * 15));
  }
  throw new Error("This room is busy right now. Please try again.");
}

async function retryRoomUpdate<T>(run: () => Promise<T>) {
  let lastError: unknown;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      return await run();
    } catch (error) {
      lastError = error;
      if (!(error instanceof Error) || !error.message.includes("room is busy")) throw error;
    }
  }
  throw lastError instanceof Error ? lastError : new Error("This room is busy right now. Please try again.");
}

async function authenticate(code: string, auth: Auth) {
  if (auth.role === "host") {
    if (!auth.hostKey) throw new Error("Host session expired. Reopen the room from this browser.");
    const keyHash = await hashSecret(auth.hostKey);
    const ctx = await fetchRoom(code);
    if (keyHash !== ctx.row.host_secret_hash) throw new Error("That host session is no longer valid.");
    return { ...ctx, player: null, memberId: "host" };
  }
  if (!auth.playerToken) throw new Error("Player session expired. Rejoin with your name.");
  const tokenHash = await hashSecret(auth.playerToken);
  const ctx = await fetchRoom(code);
  const player = ctx.room.players.find((item) => item.tokenHash === tokenHash);
  if (!player) throw new Error("That player session is no longer valid.");
  return { ...ctx, player, memberId: player.id };
}

async function writePresence(code: string, memberId: string, role: Role) {
  const db = await adminClient();
  const lastSeen = new Date().toISOString();
  const { error } = await db.from("quiz_room_presence").upsert({ room_code: code, member_id: memberId, role, last_seen: lastSeen });
  if (error) throw new Error("Could not update room presence.");
  await db.from("quiz_rooms").update({ updated_at: lastSeen }).eq("code", code);
}

async function activePresence(code: string) {
  const db = await adminClient();
  const cutoff = new Date(Date.now() - 20_000).toISOString();
  const { data, error } = await db.from("quiz_room_presence").select("member_id, role").eq("room_code", code).gte("last_seen", cutoff);
  if (error) throw new Error("Could not read room presence.");
  return data ?? [];
}

function question(room: StoredRoom, withAnswer: boolean) {
  const item = room.quiz.questions[room.qIndex];
  if (!item) return null;
  return withAnswer ? item : { text: item.text, options: item.options, time: item.time };
}

function rankRows(room: StoredRoom, connectedIds: Set<string>) {
  return standings(room.players.map((player) => ({ id: player.id, name: player.name, score: player.score, correct: player.correct }))).map((item) => ({
    ...item,
    connected: connectedIds.has(item.id),
    answered: Object.hasOwn(room.answers, item.id),
  }));
}

function makeSnapshot(room: StoredRoom, role: Role, player: Player | null, connectedIds: Set<string>, hostOnline: boolean) {
  const players = rankRows(room, connectedIds);
  const base = {
    role,
    code: "",
    phase: room.phase,
    title: room.quiz.title,
    total: room.quiz.questions.length,
    qIndex: room.qIndex,
    serverNow: Date.now(),
    endsAt: room.phase === "question" ? room.qEnd : 0,
  };
  if (role === "host") {
    return {
      ...base,
      players,
      connectedCount: connectedIds.size,
      answered: Object.keys(room.answers).length,
      question: room.phase === "question" ? question(room, false) : room.phase === "reveal" ? question(room, true) : null,
      counts: room.phase === "reveal" ? room.counts : null,
      top: room.phase === "reveal" ? players.slice(0, 5) : undefined,
      breakdown: room.phase === "final" ? room.qStats : undefined,
    };
  }
  if (!player) throw new Error("Player session not found.");
  const rank = players.find((item) => item.id === player.id);
  const previousRankScore = rank ? players.find((item) => item.rank === (rank.rank ?? 0) - 1)?.score : undefined;
  const personalAnswer = room.answers[player.id];
  return {
    ...base,
    hostOnline,
    playerCount: room.players.length,
    me: { id: player.id, name: player.name, score: player.score, rank: rank?.rank ?? 0, correct: player.correct, streak: player.streak },
    question: room.phase === "question" ? question(room, false) : room.phase === "reveal" ? question(room, true) : null,
    myChoice: room.phase === "question" ? personalAnswer?.choice ?? null : undefined,
    counts: room.phase === "reveal" ? room.counts : undefined,
    last: room.phase === "reveal" ? player.last ?? { q: room.qIndex, choice: null, correct: false, points: 0, bonus: 0 } : undefined,
    top: room.phase === "reveal" ? players.slice(0, 5) : players.slice(0, 10),
    behind: rank && rank.rank > 1 && previousRankScore !== undefined ? previousRankScore - player.score : null,
  };
}

async function settleTimer(ctx: { room: StoredRoom; db: Awaited<ReturnType<typeof adminClient>>; row: Awaited<ReturnType<typeof fetchRoom>>["row"] }, force = false) {
  const { room } = ctx;
  if (room.phase !== "question") return false;
  const currentQuestion = room.quiz.questions[room.qIndex];
  if (!currentQuestion) return false;
  const presence = await activePresence(ctx.row.code);
  const activePlayerIds = presence.filter((item) => item.role === "player").map((item) => item.member_id);
  const allOnlineAnswered = activePlayerIds.length > 0 && activePlayerIds.every((id) => Object.hasOwn(room.answers, id));
  const latestAnswer = Math.max(0, ...Object.values(room.answers).map((answer) => answer.at));
  if (!force && Date.now() <= room.qEnd + ANSWER_GRACE_MS + 100 && !(allOnlineAnswered && Date.now() - latestAnswer >= 700)) return false;
  const counts = currentQuestion.options.map(() => 0);
  const validAnswers = Object.values(room.answers).filter((answer) => Number.isInteger(answer.choice) && answer.choice >= 0 && answer.choice < currentQuestion.options.length);
  let correctCount = 0;
  for (const player of room.players) {
    const submittedAnswer = room.answers[player.id];
    const answer = submittedAnswer && Number.isInteger(submittedAnswer.choice) && submittedAnswer.choice >= 0 && submittedAnswer.choice < currentQuestion.options.length ? submittedAnswer : undefined;
    let result: NonNullable<Player["last"]> = { q: room.qIndex, choice: null, correct: false, points: 0, bonus: 0 };
    if (answer) {
      counts[answer.choice] = (counts[answer.choice] ?? 0) + 1;
      if (answer.choice === currentQuestion.correct) {
        player.streak += 1;
        const score = pointsForCorrectAnswer(answer.at - room.qStart, currentQuestion.time, player.streak);
        player.score += score.total;
        player.correct += 1;
        correctCount += 1;
        result = { q: room.qIndex, choice: answer.choice, correct: true, points: score.total, bonus: score.bonus };
      } else {
        player.streak = 0;
        result = { q: room.qIndex, choice: answer.choice, correct: false, points: 0, bonus: 0 };
      }
    } else player.streak = 0;
    player.last = result;
  }
  room.counts = counts;
  room.qStats[room.qIndex] = { text: currentQuestion.text, correct: correctCount, answered: validAnswers.length, total: room.players.length };
  room.phase = "reveal";
  return true;
}

export const createRoom = createServerFn({ method: "POST" })
  .inputValidator((input: { quiz: unknown }) => z.object({ quiz: z.unknown() }).parse(input))
  .handler(async ({ data }) => {
    const quiz = validateQuiz(data.quiz);
    if (!quiz) throw new Error("Check that each question has text, two to four answers, and a correct answer.");
    const db = await adminClient();
    const idleBefore = new Date(Date.now() - ROOM_IDLE_MS).toISOString();
    const { error: cleanupError } = await db.from("quiz_rooms").delete().lt("updated_at", idleBefore);
    if (cleanupError) throw new Error("Could not create a quiz room.");
    const { count, error: countError } = await db.from("quiz_rooms").select("code", { count: "exact", head: true });
    if (countError) throw new Error("Could not create a quiz room.");
    if ((count ?? 0) >= 500) throw new Error("The server is at room capacity. Try again shortly.");
    let code = "";
    for (let attempt = 0; attempt < 30; attempt += 1) {
      const randomValue = crypto.getRandomValues(new Uint32Array(1))[0] ?? 0;
      const candidate = String(randomValue % 900_000 + 100_000);
      const { data: existing, error } = await db.from("quiz_rooms").select("code").eq("code", candidate).maybeSingle();
      if (error) throw new Error("Could not create a quiz room.");
      if (!existing) { code = candidate; break; }
    }
    if (!code) throw new Error("Could not reserve a room code. Try again.");
    const hostKey = randomHex();
    const now = Date.now();
    const state: StoredRoom = { quiz, phase: "lobby", players: [], qIndex: -1, qStart: 0, qEnd: 0, answers: {}, counts: null, qStats: [], lastActivity: now };
    const { error } = await db.from("quiz_rooms").insert({ code, host_secret_hash: await hashSecret(hostKey), state: state as never });
    if (error) throw new Error("Could not create a quiz room.");
    await writePresence(code, "host", "host");
    return { code, hostKey, snapshot: { ...makeSnapshot(state, "host", null, new Set(), true), code } };
  });

export const joinRoom = createServerFn({ method: "POST" })
  .inputValidator((input: { code: string; name: string; playerToken?: string }) => z.object({ code: codeSchema, name: z.string().max(80), playerToken: z.string().min(32).max(128).optional() }).parse(input))
  .handler(async ({ data }) => retryRoomUpdate(async () => {
    const code = data.code.replace(/\D/g, "");
    const name = cleanText(data.name, 20);
    if (!name) throw new Error("Enter a name to join.");
    const tokenInput = data.playerToken;
    const tokenInputHash = tokenInput ? await hashSecret(tokenInput) : null;
    const result = await withRoomUpdate(code, async (ctx) => {
      const online = await activePresence(code);
      const onlineIds = new Set(online.filter((item) => item.role === "player").map((item) => item.member_id));
      let player = tokenInputHash ? ctx.room.players.find((item) => item.tokenHash === tokenInputHash) : undefined;
      if (!player) {
        const same = ctx.room.players.find((item) => item.name.toLocaleLowerCase() === name.toLocaleLowerCase());
        if (same) throw new Error(onlineIds.has(same.id) ? "Someone in this room already has that name. Try another." : "That name is already used in this room. Rejoin from the browser where you first joined, or choose another name.");
      }
      let token = tokenInput ?? "";
      if (!player) {
        if (!canAddPlayer(ctx.room.players.length)) throw new Error("This room is full.");
        token = randomHex();
        player = { id: randomHex(8), name, tokenHash: await hashSecret(token), score: 0, correct: 0, streak: 0, last: null };
        ctx.room.players.push(player);
      } else if (!token) {
        token = randomHex();
        player.tokenHash = await hashSecret(token);
      }
      player.name = name || player.name;
      ctx.room.lastActivity = Date.now();
      const ids = new Set(onlineIds);
      ids.add(player.id);
      return { token, playerId: player.id, snapshot: { ...makeSnapshot(ctx.room, "player", player, ids, online.some((item) => item.role === "host")), code } };
    });
    await writePresence(code, result.playerId, "player");
    return result;
  }));

async function readRoomState(data: { code: string; role: Role; credential: string }) {
    const auth: Auth = data.role === "host" ? { role: "host", hostKey: data.credential } : { role: "player", playerToken: data.credential };
    const initial = await authenticate(data.code, auth);
    await withRoomUpdate(data.code, async (ctx) => {
      const changed = await settleTimer(ctx);
      if (!changed) ctx.row.version = -1;
    });
    const ctx = await authenticate(data.code, auth);
    const presence = await activePresence(data.code);
    const connectedIds = new Set(presence.filter((item) => item.role === "player").map((item) => item.member_id));
    if (data.role === "player") connectedIds.add(initial.memberId);
    if (data.role === "host") connectedIds.add("host");
    await writePresence(data.code, initial.memberId, data.role);
    return { ...makeSnapshot(ctx.room, data.role, ctx.player, connectedIds, presence.some((item) => item.role === "host") || data.role === "host"), code: data.code };
}

export const readRoom = createServerFn({ method: "POST" })
  .inputValidator((input: { code: string; role: Role; credential: string }) => z.object({ code: codeSchema, role: z.enum(["host", "player"]), credential: credentialSchema }).parse(input))
  .handler(async ({ data }) => readRoomState(data));

export const actInRoom = createServerFn({ method: "POST" })
  .inputValidator((input: { code: string; role: Role; credential: string; action: z.infer<typeof actionSchema> }) => z.object({ code: codeSchema, role: z.enum(["host", "player"]), credential: credentialSchema, action: actionSchema }).parse(input))
  .handler(async ({ data }) => {
    const auth: Auth = data.role === "host" ? { role: "host", hostKey: data.credential } : { role: "player", playerToken: data.credential };
    const first = await authenticate(data.code, auth);
    const memberId = first.memberId;
    const credentialHash = await hashSecret(data.credential);
    if (data.action.action === "heartbeat") {
      await writePresence(data.code, memberId, data.role);
      return readRoomState({ code: data.code, role: data.role, credential: data.credential });
    }
    let shouldDelete = false;
    await withRoomUpdate(data.code, async (ctx) => {
      const verified = data.role === "host"
        ? credentialHash === ctx.row.host_secret_hash
        : ctx.room.players.some((player) => player.id === memberId && player.tokenHash === credentialHash);
      if (!verified) throw new Error("This session is no longer valid.");
      const now = Date.now();
      ctx.room.lastActivity = now;
      const action = data.action.action;
      if (action === "tick") {
        if (!await settleTimer(ctx)) ctx.row.version = -1;
      } else if (action === "leave") {
        await ctx.db.from("quiz_room_presence").delete().eq("room_code", data.code).eq("member_id", memberId);
        if (data.role === "player" && ctx.room.phase === "lobby") ctx.room.players = ctx.room.players.filter((player) => player.id !== memberId);
        await settleTimer(ctx);
      } else if (action === "end" && data.role === "host") {
        shouldDelete = true;
      } else if (action === "answer" && data.role === "player") {
        if (ctx.room.phase !== "question" || data.action.questionIndex !== ctx.room.qIndex || Object.hasOwn(ctx.room.answers, memberId)) return;
        if (!canAnswerAt(now, ctx.room.qEnd)) return;
        const currentQuestion = ctx.room.quiz.questions[ctx.room.qIndex];
        if (!currentQuestion || data.action.choice >= currentQuestion.options.length) return;
        ctx.room.answers[memberId] = { choice: data.action.choice, at: now };
      } else if (data.role === "host") {
        switch (action) {
          case "start":
            if (ctx.room.phase === "lobby" && ctx.room.players.length > 0) {
              const firstQuestion = ctx.room.quiz.questions[0];
              if (firstQuestion) {
                ctx.room.phase = "question"; ctx.room.qIndex = 0; ctx.room.qStart = now;
                ctx.room.qEnd = now + firstQuestion.time * 1000; ctx.room.answers = {}; ctx.room.counts = null;
              }
            }
            break;
          case "skip": await settleTimer(ctx, true); break;
          case "next":
            if (ctx.room.phase === "reveal") {
              const nextIndex = ctx.room.qIndex + 1;
              if (nextIndex >= ctx.room.quiz.questions.length) ctx.room.phase = "final";
              else {
                const nextQuestion = ctx.room.quiz.questions[nextIndex];
                if (nextQuestion) { ctx.room.phase = "question"; ctx.room.qIndex = nextIndex; ctx.room.qStart = now; ctx.room.qEnd = now + nextQuestion.time * 1000; ctx.room.answers = {}; ctx.room.counts = null; }
              }
            }
            break;
          case "kick": {
            const kickedId = data.action.playerId;
            ctx.room.players = ctx.room.players.filter((player) => player.id !== kickedId);
            delete ctx.room.answers[kickedId];
            await ctx.db.from("quiz_room_presence").delete().eq("room_code", data.code).eq("member_id", kickedId);
            break;
          }
          case "restart":
            ctx.room.phase = "lobby"; ctx.room.qIndex = -1; ctx.room.answers = {}; ctx.room.counts = null; ctx.room.qStats = [];
            ctx.room.players.forEach((player) => { player.score = 0; player.streak = 0; player.correct = 0; player.last = null; });
            break;
          default: break;
        }
      }
    });
    if (shouldDelete) {
      const db = await adminClient();
      await db.from("quiz_rooms").delete().eq("code", data.code);
      return { ended: true };
    }
    if (data.action.action === "leave") return { ended: true };
    return readRoomState({ code: data.code, role: data.role, credential: data.credential });
  });