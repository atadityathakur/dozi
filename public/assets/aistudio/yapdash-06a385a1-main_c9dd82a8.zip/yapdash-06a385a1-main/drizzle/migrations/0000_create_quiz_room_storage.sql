CREATE TABLE public.quiz_rooms (
  code text PRIMARY KEY CHECK (code ~ '^[0-9]{6}$'),
  host_secret_hash text NOT NULL,
  state jsonb NOT NULL,
  version bigint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.quiz_rooms TO service_role;
ALTER TABLE public.quiz_rooms ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.quiz_room_presence (
  room_code text NOT NULL REFERENCES public.quiz_rooms(code) ON DELETE CASCADE,
  member_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('host', 'player')),
  last_seen timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (room_code, member_id)
);
GRANT ALL ON public.quiz_room_presence TO service_role;
ALTER TABLE public.quiz_room_presence ENABLE ROW LEVEL SECURITY;
CREATE INDEX quiz_room_presence_last_seen_idx ON public.quiz_room_presence (room_code, last_seen DESC);

CREATE TABLE public.quiz_room_events (
  room_code text PRIMARY KEY REFERENCES public.quiz_rooms(code) ON DELETE CASCADE,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.quiz_room_events TO anon;
GRANT ALL ON public.quiz_room_events TO service_role;
ALTER TABLE public.quiz_room_events ENABLE ROW LEVEL SECURITY;
CREATE POLICY quiz_room_events_public_select ON public.quiz_room_events FOR SELECT TO anon USING (true);

CREATE OR REPLACE FUNCTION public.touch_quiz_room_event()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.quiz_room_events (room_code, updated_at)
  VALUES (NEW.code, clock_timestamp())
  ON CONFLICT (room_code) DO UPDATE SET updated_at = EXCLUDED.updated_at;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.touch_quiz_room_event() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER quiz_room_event_after_update
AFTER UPDATE OF state, version ON public.quiz_rooms
FOR EACH ROW EXECUTE FUNCTION public.touch_quiz_room_event();

CREATE OR REPLACE FUNCTION public.touch_quiz_presence_event()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.quiz_room_events (room_code, updated_at)
  VALUES (NEW.room_code, clock_timestamp())
  ON CONFLICT (room_code) DO UPDATE SET updated_at = EXCLUDED.updated_at;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.touch_quiz_presence_event() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER quiz_presence_event_after_change
AFTER INSERT OR UPDATE OF role ON public.quiz_room_presence
FOR EACH ROW EXECUTE FUNCTION public.touch_quiz_presence_event();

CREATE OR REPLACE FUNCTION public.quiz_room_compare_and_swap(_code text, _expected_version bigint, _new_state jsonb)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  UPDATE public.quiz_rooms
  SET state = _new_state, version = version + 1, updated_at = clock_timestamp()
  WHERE code = _code AND version = _expected_version;
  RETURN FOUND;
END;
$$;
REVOKE ALL ON FUNCTION public.quiz_room_compare_and_swap(text, bigint, jsonb) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.quiz_room_compare_and_swap(text, bigint, jsonb) TO service_role;

ALTER PUBLICATION supabase_realtime ADD TABLE public.quiz_room_events;