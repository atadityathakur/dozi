CREATE TABLE public.profiles (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text NOT NULL CHECK (username ~ '^[A-Za-z0-9_]{3,20}$'),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE UNIQUE INDEX profiles_username_lower_idx ON public.profiles (lower(username));

CREATE TABLE public.daily_yap_challenges (
  challenge_date date PRIMARY KEY,
  title text NOT NULL,
  difficulty text NOT NULL CHECK (difficulty IN ('Easy', 'Standard', 'Hard')),
  estimated_minutes integer NOT NULL CHECK (estimated_minutes BETWEEN 1 AND 30),
  questions jsonb NOT NULL CHECK (jsonb_typeof(questions) = 'array' AND jsonb_array_length(questions) BETWEEN 5 AND 10),
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.daily_yap_challenges TO service_role;
ALTER TABLE public.daily_yap_challenges ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.daily_yap_players (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  guest_token_hash text UNIQUE,
  linked_user_id uuid,
  username text NOT NULL CHECK (username ~ '^[A-Za-z0-9_]{3,20}$'),
  current_streak integer NOT NULL DEFAULT 0 CHECK (current_streak >= 0),
  longest_streak integer NOT NULL DEFAULT 0 CHECK (longest_streak >= 0),
  perfect_score_streak integer NOT NULL DEFAULT 0 CHECK (perfect_score_streak >= 0),
  longest_perfect_score_streak integer NOT NULL DEFAULT 0 CHECK (longest_perfect_score_streak >= 0),
  last_completed_date date,
  last_perfect_date date,
  created_at timestamptz NOT NULL DEFAULT now(),
  CHECK (guest_token_hash IS NOT NULL OR linked_user_id IS NOT NULL)
);
GRANT ALL ON public.daily_yap_players TO service_role;
ALTER TABLE public.daily_yap_players ENABLE ROW LEVEL SECURITY;
CREATE INDEX daily_yap_players_linked_user_idx ON public.daily_yap_players (linked_user_id) WHERE linked_user_id IS NOT NULL;
CREATE INDEX daily_yap_players_username_idx ON public.daily_yap_players (lower(username));

CREATE TABLE public.daily_yap_accounts (
  user_id uuid PRIMARY KEY,
  player_id uuid NOT NULL UNIQUE REFERENCES public.daily_yap_players(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT ALL ON public.daily_yap_accounts TO service_role;
ALTER TABLE public.daily_yap_accounts ENABLE ROW LEVEL SECURITY;

CREATE TABLE public.daily_yap_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_date date NOT NULL REFERENCES public.daily_yap_challenges(challenge_date) ON DELETE CASCADE,
  player_id uuid NOT NULL REFERENCES public.daily_yap_players(id) ON DELETE CASCADE,
  status text NOT NULL DEFAULT 'in_progress' CHECK (status IN ('in_progress', 'completed')),
  next_question integer NOT NULL DEFAULT 0 CHECK (next_question >= 0),
  question_started_at timestamptz NOT NULL DEFAULT now(),
  started_at timestamptz NOT NULL DEFAULT now(),
  completed_at timestamptz,
  score integer NOT NULL DEFAULT 0 CHECK (score >= 0),
  correct_count integer NOT NULL DEFAULT 0 CHECK (correct_count >= 0),
  total_response_ms bigint NOT NULL DEFAULT 0 CHECK (total_response_ms >= 0),
  UNIQUE (challenge_date, player_id),
  CHECK ((status = 'completed') = (completed_at IS NOT NULL))
);
GRANT ALL ON public.daily_yap_attempts TO service_role;
ALTER TABLE public.daily_yap_attempts ENABLE ROW LEVEL SECURITY;
CREATE INDEX daily_yap_attempts_date_rank_idx ON public.daily_yap_attempts (challenge_date, status, score DESC, correct_count DESC, total_response_ms ASC);
CREATE INDEX daily_yap_attempts_player_date_idx ON public.daily_yap_attempts (player_id, challenge_date DESC);

CREATE TABLE public.daily_yap_answers (
  attempt_id uuid NOT NULL REFERENCES public.daily_yap_attempts(id) ON DELETE CASCADE,
  question_index integer NOT NULL CHECK (question_index >= 0),
  selected_choice integer,
  is_correct boolean NOT NULL,
  points integer NOT NULL DEFAULT 0 CHECK (points >= 0),
  response_ms integer NOT NULL CHECK (response_ms >= 0),
  answered_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (attempt_id, question_index)
);
GRANT ALL ON public.daily_yap_answers TO service_role;
ALTER TABLE public.daily_yap_answers ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.handle_new_daily_yap_profile()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base_name text;
  candidate text;
  suffix integer := 0;
BEGIN
  base_name := 'player_' || substr(replace(NEW.id::text, '-', ''), 1, 10);
  candidate := base_name;
  WHILE EXISTS (SELECT 1 FROM public.profiles WHERE lower(username) = lower(candidate)) LOOP
    suffix := suffix + 1;
    candidate := base_name || suffix::text;
  END LOOP;
  INSERT INTO public.profiles (user_id, username)
  VALUES (NEW.id, candidate)
  ON CONFLICT (user_id) DO NOTHING;
  RETURN NEW;
END;
$$;
REVOKE ALL ON FUNCTION public.handle_new_daily_yap_profile() FROM PUBLIC, anon, authenticated;
DROP TRIGGER IF EXISTS on_auth_user_created_daily_yap_profile ON auth.users;
CREATE TRIGGER on_auth_user_created_daily_yap_profile
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_daily_yap_profile();

CREATE OR REPLACE FUNCTION public.ensure_daily_yap_account(_user_id uuid, _username text, _guest_token_hash text DEFAULT NULL)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  account_player uuid;
  guest_player uuid;
BEGIN
  PERFORM pg_advisory_xact_lock(hashtext(_user_id::text));
  SELECT player_id INTO account_player FROM public.daily_yap_accounts WHERE user_id = _user_id FOR UPDATE;
  IF account_player IS NOT NULL THEN
    UPDATE public.daily_yap_players SET username = _username WHERE id = account_player;
    UPDATE public.daily_yap_players SET linked_user_id = _user_id, username = _username
    WHERE linked_user_id IS NULL AND guest_token_hash = _guest_token_hash AND _guest_token_hash IS NOT NULL;
    RETURN account_player;
  END IF;

  IF _guest_token_hash IS NOT NULL THEN
    SELECT id INTO guest_player FROM public.daily_yap_players WHERE guest_token_hash = _guest_token_hash FOR UPDATE;
  END IF;
  IF guest_player IS NOT NULL THEN
    UPDATE public.daily_yap_players SET linked_user_id = _user_id, username = _username WHERE id = guest_player;
    account_player := guest_player;
  ELSE
    INSERT INTO public.daily_yap_players (linked_user_id, username)
    VALUES (_user_id, _username)
    RETURNING id INTO account_player;
  END IF;
  INSERT INTO public.daily_yap_accounts (user_id, player_id) VALUES (_user_id, account_player);
  RETURN account_player;
END;
$$;
REVOKE ALL ON FUNCTION public.ensure_daily_yap_account(uuid, text, text) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.ensure_daily_yap_account(uuid, text, text) TO service_role;

CREATE OR REPLACE FUNCTION public.daily_yap_start_attempt(_player_id uuid, _challenge_date date)
RETURNS public.daily_yap_attempts
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  account_user uuid;
  found_attempt public.daily_yap_attempts;
  new_attempt public.daily_yap_attempts;
  question_count integer;
BEGIN
  IF _challenge_date <> (clock_timestamp() AT TIME ZONE 'UTC')::date THEN
    RAISE EXCEPTION 'The daily challenge date has changed';
  END IF;
  PERFORM 1 FROM public.daily_yap_players WHERE id = _player_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Player not found'; END IF;
  SELECT user_id INTO account_user FROM public.daily_yap_accounts WHERE player_id = _player_id;
  IF account_user IS NULL THEN SELECT linked_user_id INTO account_user FROM public.daily_yap_players WHERE id = _player_id; END IF;
  PERFORM pg_advisory_xact_lock(hashtext(COALESCE(account_user::text, _player_id::text)));
  IF NOT EXISTS (SELECT 1 FROM public.daily_yap_challenges WHERE challenge_date = _challenge_date) THEN
    RAISE EXCEPTION 'Daily challenge is not available';
  END IF;
  IF account_user IS NULL THEN
    SELECT * INTO found_attempt FROM public.daily_yap_attempts WHERE challenge_date = _challenge_date AND player_id = _player_id LIMIT 1;
  ELSE
    SELECT a.* INTO found_attempt
    FROM public.daily_yap_attempts a
    JOIN public.daily_yap_players p ON p.id = a.player_id
    LEFT JOIN public.daily_yap_accounts ac ON ac.player_id = p.id
    WHERE a.challenge_date = _challenge_date
      AND (ac.user_id = account_user OR p.linked_user_id = account_user)
    ORDER BY a.started_at
    LIMIT 1;
  END IF;
  IF FOUND THEN RETURN found_attempt; END IF;
  SELECT jsonb_array_length(questions) INTO question_count
  FROM public.daily_yap_challenges WHERE challenge_date = _challenge_date;
  INSERT INTO public.daily_yap_attempts (challenge_date, player_id, next_question, question_started_at)
  VALUES (_challenge_date, _player_id, 0, clock_timestamp())
  ON CONFLICT (challenge_date, player_id) DO NOTHING;
  SELECT * INTO new_attempt FROM public.daily_yap_attempts WHERE challenge_date = _challenge_date AND player_id = _player_id;
  RETURN new_attempt;
END;
$$;
REVOKE ALL ON FUNCTION public.daily_yap_start_attempt(uuid, date) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.daily_yap_start_attempt(uuid, date) TO service_role;

CREATE OR REPLACE FUNCTION public.daily_yap_submit_answer(_attempt_id uuid, _question_index integer, _choice integer)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  attempt_row public.daily_yap_attempts;
  challenge_row public.daily_yap_challenges;
  question_row jsonb;
  question_total integer;
  time_limit integer;
  response_time integer;
  answer_choice integer;
  answer_correct boolean;
  awarded_points integer;
  transaction_time timestamptz := clock_timestamp();
  new_streak integer;
  new_perfect_streak integer;
  old_last_date date;
  old_last_perfect_date date;
  canonical_player uuid;
  daily_milestone integer;
BEGIN
  SELECT * INTO attempt_row FROM public.daily_yap_attempts WHERE id = _attempt_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'Attempt not found'; END IF;
  IF attempt_row.status = 'completed' THEN
    RETURN jsonb_build_object('completed', true, 'alreadySubmitted', true);
  END IF;
  IF _question_index < attempt_row.next_question THEN
    RETURN jsonb_build_object('completed', false, 'alreadySubmitted', true, 'nextQuestion', attempt_row.next_question);
  END IF;
  IF _question_index <> attempt_row.next_question THEN RAISE EXCEPTION 'Question is not active'; END IF;
  SELECT * INTO challenge_row FROM public.daily_yap_challenges WHERE challenge_date = attempt_row.challenge_date;
  question_total := jsonb_array_length(challenge_row.questions);
  question_row := challenge_row.questions -> _question_index;
  IF question_row IS NULL THEN RAISE EXCEPTION 'Question not found'; END IF;
  time_limit := (question_row ->> 'time')::integer;
  IF transaction_time > attempt_row.question_started_at + make_interval(secs => time_limit) THEN
    answer_choice := NULL;
  ELSE
    IF _choice = -1 THEN
      RETURN jsonb_build_object('completed', false, 'waiting', true, 'nextQuestion', attempt_row.next_question);
    END IF;
    IF _choice < 0 OR _choice >= jsonb_array_length(question_row -> 'options') THEN
      RAISE EXCEPTION 'Answer choice is invalid';
    END IF;
    answer_choice := _choice;
  END IF;
  answer_correct := answer_choice IS NOT NULL AND answer_choice = (question_row ->> 'correct')::integer;
  response_time := LEAST(time_limit * 1000, GREATEST(0, FLOOR(EXTRACT(EPOCH FROM (transaction_time - attempt_row.question_started_at)) * 1000)::integer));
  awarded_points := CASE WHEN answer_correct THEN ROUND(500 + 500 * GREATEST(0::numeric, 1 - response_time::numeric / (time_limit * 1000)))::integer ELSE 0 END;
  INSERT INTO public.daily_yap_answers (attempt_id, question_index, selected_choice, is_correct, points, response_ms, answered_at)
  VALUES (_attempt_id, _question_index, answer_choice, answer_correct, awarded_points, response_time, transaction_time);
  UPDATE public.daily_yap_attempts
  SET next_question = attempt_row.next_question + 1,
      score = attempt_row.score + awarded_points,
      correct_count = attempt_row.correct_count + CASE WHEN answer_correct THEN 1 ELSE 0 END,
      total_response_ms = attempt_row.total_response_ms + response_time,
      question_started_at = CASE WHEN attempt_row.next_question + 1 < question_total THEN transaction_time ELSE attempt_row.question_started_at END,
      status = CASE WHEN attempt_row.next_question + 1 >= question_total THEN 'completed' ELSE 'in_progress' END,
      completed_at = CASE WHEN attempt_row.next_question + 1 >= question_total THEN transaction_time ELSE NULL END
  WHERE id = _attempt_id
  RETURNING * INTO attempt_row;

  IF attempt_row.status = 'completed' THEN
    SELECT COALESCE(ac.player_id, attempt_row.player_id) INTO canonical_player
    FROM public.daily_yap_players p
    LEFT JOIN public.daily_yap_accounts ac ON ac.user_id = COALESCE(p.linked_user_id, (SELECT user_id FROM public.daily_yap_accounts WHERE player_id = p.id))
    WHERE p.id = attempt_row.player_id;
    SELECT current_streak, longest_streak, perfect_score_streak, longest_perfect_score_streak, last_completed_date, last_perfect_date
    INTO new_streak, daily_milestone, new_perfect_streak, canonical_player, old_last_date, old_last_perfect_date
    FROM public.daily_yap_players WHERE id = canonical_player FOR UPDATE;
    new_streak := CASE WHEN old_last_date = attempt_row.challenge_date THEN new_streak WHEN old_last_date = attempt_row.challenge_date - 1 THEN new_streak + 1 ELSE 1 END;
    new_perfect_streak := CASE
      WHEN attempt_row.correct_count = question_total AND old_last_perfect_date = attempt_row.challenge_date THEN new_perfect_streak
      WHEN attempt_row.correct_count = question_total AND old_last_perfect_date = attempt_row.challenge_date - 1 THEN new_perfect_streak + 1
      WHEN attempt_row.correct_count = question_total THEN 1
      ELSE 0
    END;
    UPDATE public.daily_yap_players
    SET current_streak = new_streak,
        longest_streak = GREATEST(longest_streak, new_streak),
        perfect_score_streak = new_perfect_streak,
        longest_perfect_score_streak = GREATEST(longest_perfect_score_streak, new_perfect_streak),
        last_completed_date = attempt_row.challenge_date,
        last_perfect_date = CASE WHEN attempt_row.correct_count = question_total THEN attempt_row.challenge_date ELSE last_perfect_date END
    WHERE id = canonical_player;
    IF old_last_date IS DISTINCT FROM attempt_row.challenge_date AND new_streak IN (3, 7, 14, 30) THEN daily_milestone := new_streak; ELSE daily_milestone := NULL; END IF;
  END IF;
  RETURN jsonb_build_object(
    'completed', attempt_row.status = 'completed',
    'waiting', false,
    'nextQuestion', attempt_row.next_question,
    'score', attempt_row.score,
    'correctCount', attempt_row.correct_count,
    'serverNow', FLOOR(EXTRACT(EPOCH FROM transaction_time) * 1000)::bigint,
    'milestone', daily_milestone
  );
END;
$$;
REVOKE ALL ON FUNCTION public.daily_yap_submit_answer(uuid, integer, integer) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.daily_yap_submit_answer(uuid, integer, integer) TO service_role;

CREATE OR REPLACE FUNCTION public.daily_yap_leaderboards(_today date, _player_id uuid DEFAULT NULL)
RETURNS jsonb
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
WITH attempt_rows AS (
  SELECT a.challenge_date, a.player_id, a.score, a.correct_count, a.total_response_ms,
         jsonb_array_length(c.questions) AS question_count, a.completed_at, p.username,
         COALESCE(ac.user_id::text, p.linked_user_id::text, 'guest:' || p.id::text) AS principal_id
  FROM public.daily_yap_attempts a
  JOIN public.daily_yap_challenges c ON c.challenge_date = a.challenge_date
  JOIN public.daily_yap_players p ON p.id = a.player_id
  LEFT JOIN public.daily_yap_accounts ac ON ac.player_id = p.id
  WHERE a.status = 'completed' AND a.challenge_date BETWEEN _today - 6 AND _today
), selected AS (
  SELECT DISTINCT ON (challenge_date, principal_id) *
  FROM attempt_rows
  ORDER BY challenge_date, principal_id, score DESC, correct_count DESC, total_response_ms ASC, completed_at ASC
), daily_ranked AS (
  SELECT *, RANK() OVER (ORDER BY score DESC, correct_count DESC, total_response_ms ASC) AS position
  FROM selected WHERE challenge_date = _today
), weekly_totals AS (
  SELECT principal_id, MAX(username) AS username, SUM(score)::integer AS score,
         SUM(correct_count)::integer AS correct_count, SUM(total_response_ms)::bigint AS total_response_ms,
         SUM(question_count)::integer AS total_questions, COUNT(*)::integer AS challenges_played
  FROM selected GROUP BY principal_id
), weekly_ranked AS (
  SELECT *, RANK() OVER (ORDER BY score DESC, correct_count DESC, total_response_ms ASC) AS position
  FROM weekly_totals
), target AS (
  SELECT COALESCE(ac.user_id::text, p.linked_user_id::text, 'guest:' || p.id::text) AS principal_id
  FROM public.daily_yap_players p LEFT JOIN public.daily_yap_accounts ac ON ac.player_id = p.id
  WHERE p.id = _player_id
), daily_json AS (
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'rank', position, 'username', username, 'score', score, 'correctCount', correct_count,
    'accuracy', ROUND(100.0 * correct_count / NULLIF(question_count, 0))::integer,
    'completionMs', total_response_ms
  ) ORDER BY position, username), '[]'::jsonb) AS rows FROM (SELECT * FROM daily_ranked ORDER BY position, username LIMIT 10) x
), weekly_json AS (
  SELECT COALESCE(jsonb_agg(jsonb_build_object(
    'rank', position, 'username', username, 'score', score, 'correctCount', correct_count,
    'accuracy', ROUND(100.0 * correct_count / NULLIF(total_questions, 0))::integer,
    'completionMs', total_response_ms, 'challengesPlayed', challenges_played
  ) ORDER BY position, username), '[]'::jsonb) AS rows FROM (SELECT * FROM weekly_ranked ORDER BY position, username LIMIT 10) x
)
SELECT jsonb_build_object(
  'daily', daily_json.rows,
  'weekly', weekly_json.rows,
  'dailyRank', (SELECT dr.position FROM daily_ranked dr JOIN target t USING (principal_id) LIMIT 1),
  'weeklyRank', (SELECT wr.position FROM weekly_ranked wr JOIN target t USING (principal_id) LIMIT 1)
)
FROM daily_json, weekly_json;
$$;
REVOKE ALL ON FUNCTION public.daily_yap_leaderboards(date, uuid) FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.daily_yap_leaderboards(date, uuid) TO service_role;