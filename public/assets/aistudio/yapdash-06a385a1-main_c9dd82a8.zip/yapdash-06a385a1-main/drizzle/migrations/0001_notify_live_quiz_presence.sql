DROP TRIGGER quiz_presence_event_after_change ON public.quiz_room_presence;
CREATE TRIGGER quiz_presence_event_after_change
AFTER INSERT OR UPDATE OF last_seen ON public.quiz_room_presence
FOR EACH ROW EXECUTE FUNCTION public.touch_quiz_presence_event();