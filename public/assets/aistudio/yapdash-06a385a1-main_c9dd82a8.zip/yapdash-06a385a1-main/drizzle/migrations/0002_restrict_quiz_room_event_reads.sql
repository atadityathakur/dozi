DROP POLICY IF EXISTS quiz_room_events_public_select ON public.quiz_room_events;
REVOKE SELECT ON public.quiz_room_events FROM anon;